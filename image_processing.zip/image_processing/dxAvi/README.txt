This library contains helper functions to read image frames into matlab from an AVI 
file using DirectShow.

It hence,
a) does not suffer from the 2Gb file limit 
b) handles most codecs installed on the system
c) but only works for windows :(

-- Depending on your Matlab version, the .mexw32 files may need to be renamed as .dll

-- testDxAvi.m is a simple example, should now pretty much run off the bat. 

   The library usage is as follows,

	[avi_hdl, avi_inf] = dxAviOpen(avi_filename);
	pixmap = dxAviReadMex(avi_hdl, frame_num);
	img = reshape(pixmap,[avi_inf.Height,avi_inf.Width,3]);
	dxAviCloseMex(avi_hdl);

-- mex_cmd.m if you want to recompile the library
	BaseClasses is from "Direct X 9.0 SDK 2002" (Google should get you this)
	Code here based on GrabBitmaps.cpp in DirectShow samples (there are many other awesome samples). 
	It is quite wierd that the new DirectX distributions does not have these samples. 
	I have only tested with VC++ 7 compiler (run mex -setup for this).

Have Fun!
Ashwin Thangali -- Feb 2006
