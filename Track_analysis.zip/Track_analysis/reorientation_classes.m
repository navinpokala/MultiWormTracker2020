function s = reorientation_classes

s{1} = 'pure_omega';
s{2} = 'lRevOmega';
s{3} = 'sRevOmega';

s{4} = 'pure_upsilon';
s{5} = 'lRevUpsilon';
s{6} = 'sRevUpsilon';

s{7} = 'pure_lRev';
s{8} = 'pure_sRev';

return;
end
