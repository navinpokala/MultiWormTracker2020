function custom_start(obj)
%START Start timer(s) running.
%
%    START(OBJ) starts the timer running, represented by the timer 
%    object, OBJ. If OBJ is an array of timer objects, START starts 
%    all the timers. Use the TIMER function to create a timer object.
%
%    START sets the Running property of the timer object, OBJ, to 'On',
%    initiates TimerFcn callbacks, and executes the StartFcn callback.
%
%    The timer stops running when one of the following conditions apply:
%     - The number of TimerFcn callbacks executed equals the number 
%       specified by the TasksToExecute property.
%     - The STOP(OBJ) command is issued.
%     - An error occurs while executing a TimerFcn callback.
%   
%    See also TIMER, TIMER/STOP.

%    RDD 11-20-2001
%    Copyright 2001-2007 The MathWorks, Inc.
%    $Revision: 1.3.4.6 $  $Date: 2011/03/28 04:34:58 $


% copy whole timer directory

len = length(obj);

if ~all(isJavaTimer(obj.jobject))
   if len==1
       error(message('MATLAB:timer:invalid'));
   else        
       error(message('MATLAB:timer:someinvalid'));
   end
end

err = false;
alreadyRunning = false;
for lcv = 1:len % foreach object in OBJ array
    if (obj.jobject(lcv).isRunning == 1) % if timer already running, flag as error/warning
        alreadyRunning = true;
    else
        try
            obj.jobject(lcv).start; % start the timer
        catch exception
            err = true; % flag as error/warning needing to be thrown at end
        end
    end
end

if (len==1) % if OBJ is singleton, above problems are thrown as errors
    if alreadyRunning
        error(message('MATLAB:timer:alreadystarted'));
    elseif err % throw actual error
        throw(fixexception(exception));
    end
else % if OBJ is an array, above problems are thrown as warnings
    if alreadyRunning
        state = warning('backtrace','off');
        warning(message('MATLAB:timer:alreadystarted'));
        warning(state);
    elseif err
        state = warning('backtrace','off');
        warning(message('MATLAB:timer:errorinobjectarray'));
        warning(state);
    end
end


function out = isJavaTimer(obj)
%ISJAVATIMER Returns logical indicating if object is a Java timer
%
%    ISJAVATIMER(OBJ) returns a logical indicating if OBJ is a
%    instance of the java timer object.

%    RDD 1-18-2002
%    Copyright 2001-2002 The MathWorks, Inc. 
%    $Revision: 1.3 $  $Date: 2002/03/14 14:35:16 $

out = false;
for lcv=1:length(obj)
    out(lcv) = isa(obj(lcv),'javahandle.com.mathworks.timer.TimerTask');
end

% Reshape the out variable to be the same shape as the input object.
% This is needed is obj is a column vector.
if (size(out) ~= size(obj))
    out = out';
end

function exception = fixexception(exception)
%fixexception modifies the exception to hide any java timer object references.
%
%    FIXEXCEPTION replaces references
%    to the java timer object with more generic 'timer object'.
%
%    See Also: ERROR

%    Copyright 2001-2007 The MathWorks, Inc. 
%    $Revision: 1.1.6.1 $  $Date: 2008/03/17 22:17:41 $

lerr = exception.message;

% look for the java object references in the text and replace the text with more generic version
lerr = strrep(lerr, 'javahandle.', '');
lerr = strrep(lerr, 'in the ''com.mathworks.timer.TimerTask'' class', 'for timer objects');
lerr = strrep(lerr, 'class com.mathworks.timer.TimerTask', 'timer objects');
lerr = strrep(lerr, 'com.mathworks.timer.TimerTask', 'timer objects');

exception = MException(exception.identifier, '%s', lerr);

function deleteAsync(obj, event)
%Private helper function for deletion of the timer objects.  This function
%is called asynchronously, through timercb, when a timer is to be deleted.
%An asynchronous call ensures that any other events in the queue, like a
%stop, are handled first.

% Copyright 2004-2007 The MathWorks, Inc.

len = length(obj);
for lcv=1:len
    try
        obj.jobject(lcv).dispose;
		obj.jobject(lcv).delete;
		mltimerpackage('Delete',obj.jobject(lcv));
    catch exc %#ok<NASGU>
    end
end

function [propnames,props] = getSettableValues(obj)
%getSettableValues gets all the settable values of a timer object array
%
%    getSettableValues(OBJ) returns the settable values of OBJ as a list of settable
%    property names and a cell array containing the values.
%
%    See Also: TIMER/PRIVATE/RESETVALUES

%    RDD 1-18-2002
%    Copyright 2001-2006 The MathWorks, Inc.
%    $Revision: 1.2.4.2 $  $Date: 2006/06/20 20:11:42 $

objlen = length(obj);

propnames = [];
% foreach valid timer object...
for objnum=1:objlen
    if isJavaTimer(obj.jobject(objnum)) % valid java object found
        if isempty(propnames) % if settable propnames are not yet known, get them from set
            propnames = fieldnames(set(obj.jobject(objnum)));
        end
        % the settable values of the valid timer object
        props{objnum} = get(obj.jobject(objnum),propnames);
    end
end

function resetValues(obj, pNames, pVals)
%resetValues resets the properties of a timer object
%
%    RESETVALUES(OBJ,PNAMES,PVALS) sets the properties of OBJ.  PNAMES and PVALS 
%    are values from the GETSETTABLEVALUES function.
%
%    See Also: TIMER/PRIVATE/GETSETTABLEVALUES
%

%    RDD 1-18-2002
%    Copyright 2001-2007 The MathWorks, Inc.
%    $Revision: 1.2.4.1 $  $Date: 2007/12/06 13:30:43 $

olen = length(obj);
j=obj.jobject;

% foreach valid object...
for lcv=1:olen
    if isJavaTimer(j(lcv))
        for props=1:length(pNames)
            try
                set(j(lcv),pNames{props},pVals{lcv}{props});
            catch exc  %#ok<NASGU>
            end
        end
    end
end


