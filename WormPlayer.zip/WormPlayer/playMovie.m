function playMovie (hbutton, eventStruct, hfig)
if nargin<3, hfig  = gcbf; end

movieData = get(hfig,'userdata');
icons = get_icons_from_fig(hfig);
hPlay = findobj(movieData.htoolbar, 'tag','Play/Pause');

if strcmp(movieData.play, 'on')
    set(hPlay, ...
     ...  % 'tooltip', 'Resume', ...
        'cdata', icons.play_on);
    movieData.play = 'off';
    stop(movieData.movieTimer);
    set(hfig,'userdata', movieData);
    return;
end

movieData.play = 'on';

% if(~isempty(findstr('2011',version)))
%     start(movieData.movieTimer);
% else  % start timer function has some issue in newer versions of matlab, so this will play 10 sec
    fn_start = movieData.FrameNum;
    fn_end = min(movieData.Tracks(movieData.TrackNum).Frames(end), fn_start + 10*movieData.fps);
    for FrameNum = fn_start:fn_end
        movieData.FrameNum = FrameNum;
        movieData.TrackFrame = movieData.FrameNum - movieData.Tracks(movieData.TrackNum).Frames(1) + 1;
        set(hfig,'userdata', movieData);
        displayFrame(hfig);
        pause(0.5*1/movieData.fps);
    end
% end

set(hPlay, ...
   ...  %       'tooltip', 'Resume', ...
    'cdata', icons.play_off);

set(hfig,'userdata', movieData);


end

