function mag = vector_magnitude(a)

mag = sqrt(sum(a(1:end).^2));

return;
end
