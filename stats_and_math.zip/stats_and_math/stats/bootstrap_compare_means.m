function [p_empirical_cdf, p_norm_cdf, p_ttest] = bootstrap_compare_means(sample, ctrl, n)
%  [p_empirical_cdf, p_ncdf, p_ttest] = bootstrap_compare(sample, ctrl, [n=1000])
% p_empirical_cdf = p from empirical CDF ... p lower limit is 1/n
% p_norm_cdf = p from normalized CDF of bootstrapped samples
% p_ttest = p from ttest comparing sample and ctrl

if(nargin<2)
    disp('usage: [p_empirical_cdf, p_norm_cdf, p_ttest] = bootstrap_compare(sample, ctrl, [n=1000])');
    return;
end

if(nargin<3)
    n=1000;
end

% check for dimensions and convert to row vectors
if(size(ctrl,1)~=1)
    ctrl = ctrl';
end
if(size(sample,1)~=1)
    sample = sample';
end

% purge nans
ctrl(isnan(ctrl))=[];
sample(isnan(sample))=[];

n_ctrl = length(ctrl);
n_sample = length(sample);
n_total = n_ctrl+n_sample;

actual_mean_diff = abs(mean(ctrl) - mean(sample));

mean_diff_vector(n) = 0;
for(i=1:n)
    pooled_data = [sample ctrl];
    
    idx = randint(n_total,n_ctrl);
    dummy_ctrl = pooled_data(idx);
    pooled_data(idx) = [];
    dummy_sample = pooled_data;
   
    mean_diff_vector(i) = abs(mean(dummy_ctrl) - mean(dummy_sample));
    
end

if(sum(mean_diff_vector)==0)
    p=1;
    return;
end

[cumdist, t] = cumulative_distribution(mean_diff_vector);
idx = find(t >= actual_mean_diff);
if(isempty(idx))
    p_empirical_cdf = 1/n;
else
    idx = idx(1);
    p_empirical_cdf = cumdist(idx);
end

p_norm_cdf = 1-normcdf(actual_mean_diff, mean(mean_diff_vector), std(mean_diff_vector));
[~,p_ttest]=ttest2(ctrl, sample);

% [p_empirical_cdf p_norm_cdf p_ttest actual_mean_diff mean(mean_diff_vector) std(mean_diff_vector)]
% figure(100);
% hist(mean_diff_vector,sshist(mean_diff_vector));
% hold on;
% plot(abs(mean(ctrl) - mean(sample)),0,'or','MarkerSize',12,'MarkerFaceColor',[1 0 0]);
% hold off
% figure(200);
% plot(t,cumdist,'.','markersize',12); 
% hold on;
% plot(actual_mean_diff, p_empirical_cdf,'ok','MarkerSize',12); % ,'MarkerFaceColor',[1 1 1]);
% plot(actual_mean_diff, p_norm_cdf,'or','MarkerSize',12); % ,'MarkerFaceColor',[1 0 0]);
% plot(actual_mean_diff, p_ttest,'og','MarkerSize',12); %,'MarkerFaceColor',[0 1 0]);
% hold off


return;
end
