function binary_text = random_binary_number(lower, upper)

binary_text = number_to_binary(bracketed_rand(lower, upper));

return;
end
