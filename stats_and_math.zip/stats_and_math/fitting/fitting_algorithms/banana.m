function z = banana(x)
% min at [1 1]

z = 100*(x(2)-x(1)^2)^2+(1-x(1))^2; 

return;
end
