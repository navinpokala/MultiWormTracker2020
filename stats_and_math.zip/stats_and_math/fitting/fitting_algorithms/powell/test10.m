function S=test(x)
% Edgar & Himmelblau, 1988
% x0 = [1, 2]'
% xo = [0, 0]'
% S(xo) = 0

S=4*x(1).^2-2.*x(1).*x(2)+x(2).^2;
