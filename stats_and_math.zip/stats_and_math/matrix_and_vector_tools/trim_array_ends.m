% remove first and last elements from the array
function y = trim_array_ends(x)

y=x(2: (length(x)-1));

return;
end