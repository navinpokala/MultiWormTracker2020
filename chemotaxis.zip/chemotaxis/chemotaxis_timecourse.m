function [CI, frames, num_target, num_control, total_numworms] = chemotaxis_timecourse(filename, procFrame)

[PathName, FilePrefix] = fileparts(filename);
if(isempty(PathName))
    PathName = pwd;
end
if(nargin<2)
    fn = sprintf('%s%s%s.procFrame.mat',PathName,filesep,FilePrefix);
    disp(sprintf('Loading %s\t%s',fn,timeString))
    procFrame = load_procFrame(fn);
end

num_frames = length(procFrame);

num_worms = []; worm_areas = [];
for(i=1:num_frames)
    num_worms = [num_worms length(procFrame(i).worm)];
    for(j=1:length(procFrame(i).worm))
        worm_areas = [worm_areas procFrame(i).worm(j).size];
    end
end
total_numworms = max(num_worms);
mean_worm_area = nanmean(worm_areas);

Mov = aviread_to_gray(filename,num_frames);

target_verticies = [];
fn = sprintf('%s%s%s.chemotaxis_regions.mat',PathName,filesep,FilePrefix);
load(fn);
if(size(target_verticies,1)<3 || size(control_verticies,1)<3)
    [target_verticies, target_point, control_verticies, control_point] = select_odor_control_regions_chemotaxis(Mov.cdata);
end

target_mask = poly2mask(target_verticies(:,1), target_verticies(:,2), size(Mov.cdata,1), size(Mov.cdata,2));
control_mask = poly2mask(control_verticies(:,1), control_verticies(:,2), size(Mov.cdata,1), size(Mov.cdata,2));

Mov = aviread_to_gray(filename,1);
first_frame = double(Mov.cdata);

num_target =[]; num_control = []; CI=[]; frames = [];
k=0;
for(i=1:3*60*5:num_frames)
    k=k+1;
    
    frames(k) = i;
    
    % load frames in chunks for greater efficiency
    if(i==1 || mod(i,100)==0)
        aviread_to_gray;
        aviread_to_gray(filename, i:min((i+100),num_frames));
    end
    
    % subtract the background from the frame and mask out the ring
    Movsubtract = background_subtracted_frame(filename, i, first_frame);
    aviread_to_gray(filename, i, 'clear');
    
    px = matrix_to_vector(Movsubtract);
    median_inten = mean(px) + 8*std(px);
    
    target = Movsubtract.*target_mask - median_inten;
    control = Movsubtract.*control_mask - median_inten;
    
    
    target_idx = find(target > 0);
    control_idx = find(control > 0);
    
    num_target(k) = length(target_idx)/mean_worm_area;
    num_control(k) = length(control_idx)/mean_worm_area;
    
    % in case num_target or num_control estimated from intensity >
    % total_numworms calc'd from procFrames
    CI(k) = (min(total_numworms,num_target(end)) - min(total_numworms,num_control(end)))/total_numworms;
    
end

return;
end

% number of worms = max(number of worms from procFrame
% avg worm area
% subtract frame1 from each frame, get #pixels>0 intensity in (target and ctrl) - median bkgnd subtracted intensity overall
% divide
