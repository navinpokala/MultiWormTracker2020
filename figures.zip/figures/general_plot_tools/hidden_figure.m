function h = hidden_figure(fignum)

h = figure(fignum);
set(gcf,'visible','off');

return;
end
